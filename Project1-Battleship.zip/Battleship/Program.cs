﻿
using var game = new Battleship.BattleshipGame();
game.Run();
