﻿public enum GameState
{
    MainMenu,
    Playing,
    ShipSelection,
    Settings,
    Postgame,
    Exit
}