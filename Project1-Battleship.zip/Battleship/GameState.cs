﻿public enum GameState
{
    MainMenu,
    Playing,
    ShipSelection,
    Settings,
    Exit
}