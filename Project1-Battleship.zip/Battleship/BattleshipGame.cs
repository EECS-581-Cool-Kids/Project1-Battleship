﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Diagnostics;
using System.Diagnostics.Tracing;

namespace Battleship
{
    public class BattleshipGame : Game
    {
       /// <summary>
        /// The MonoGame Graphics Device Manager.
        /// </summary>
        private GraphicsDeviceManager _graphics;

        /// <summary>
        /// The MonoGame sprit batch object.
        /// </summary>
        private SpriteBatch? _spriteBatch;

        /// <summary>
        /// The player's cursor.
        /// </summary>
        private Cursor _cursor = new();

        /// <summary>
        /// Player 1 grid object.
        /// </summary>
        private Grid? _player1grid;

        /// <summary>
        /// Player 2 grid object.
        /// </summary>
        private Grid? _player2grid;

        /// <summary>
        /// The internal ship manager object.
        /// </summary>
        private ShipManager? _shipManager;

        private bool inGame = false;
        private GameState currentGameState;
        private Menu menu;
        private ShipSelectionMenu shipSelectionMenu;
        private SpriteFont font;
        public int shipCount;
        SpriteBatch spriteBatch;

        public BattleshipGame()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        /// <summary>
        /// Initializes the relevant objects and window. 
        /// Called once at startup.
        /// </summary>
        protected override void Initialize()
        {
            _graphics.IsFullScreen = false;
            _graphics.PreferredBackBufferWidth = Constants.SQUARE_SIZE * Constants.GRID_SIZE * 2 * Constants.SCALE;
            _graphics.PreferredBackBufferHeight = Constants.SQUARE_SIZE * Constants.GRID_SIZE * Constants.SCALE;
            _graphics.ApplyChanges();

            Window.Title = "Battleship";

            _player1grid = new Grid(Constants.GRID_SIZE, Constants.PLAYER_1_OFFSET);
            _player2grid = new Grid(Constants.GRID_SIZE, Constants.PLAYER_2_OFFSET);
            if (inGame)
            { 
                _shipManager = new ShipManager(shipCount);
            }
            else
            {
                shipCount = 3;
                _shipManager = new ShipManager(shipCount);
            }
            // add event handlers
            _shipManager.OnPlayer1ShipPlaced = _player1grid.ShipPlaced;
            _shipManager.OnPlayer2ShipPlaced = _player2grid.ShipPlaced;
            _shipManager.OnPlayer1AdjustedTileRequested = _player1grid.GetAdjustedCurrentTile;
            _shipManager.OnPlayer2AdjustedTileRequested = _player2grid.GetAdjustedCurrentTile;
            _shipManager.IsPlayer1PlacementValid = _player1grid.IsShipPlacementValid;
            _shipManager.IsPlayer2PlacementValid = _player2grid.IsShipPlacementValid;


            base.Initialize();
        }

        /// <summary>
        /// Loads all texture content.
        /// Called once at startup.
        /// </summary>
        protected override void LoadContent()
        {
            if (!inGame)
            {
                _spriteBatch = new SpriteBatch(GraphicsDevice);
                font = Content.Load<SpriteFont>("defaultFont");

                // Initialize the main menu and ship selection menu
                menu = new Menu(font);
                shipSelectionMenu = new ShipSelectionMenu(font);
                return;
            }
            else
            {
                _spriteBatch = new SpriteBatch(GraphicsDevice);

                _player1grid!.LoadContent(Content);
                _player2grid!.LoadContent(Content);
                _shipManager!.LoadContent(Content);
                _cursor.LoadContent(Content);
            }
        }
        
        /// <summary>
        /// Checks if any game logic has updated. Called constantly in a loop.
        /// </summary>
        /// <param name="gameTime">The current game time.</param>
        protected override void Update(GameTime gameTime)
        {
            if (!inGame)
            {
                switch (currentGameState)
                {
                    case GameState.MainMenu:
                        menu.Update();
                        if (menu.SelectedState == GameState.ShipSelection)
                        {
                            currentGameState = GameState.ShipSelection;
                        }
                        else if (menu.SelectedState == GameState.Exit)
                        {
                            Exit();
                        }
                        break;

                    case GameState.ShipSelection:
                        shipSelectionMenu.Update();

                        // When "Start Game" is clicked, transition to playing
                        if (shipSelectionMenu.IsSelectionMade)
                        {
                            shipCount = shipSelectionMenu.SelectedShipCount;  // Store the selected ship count
                            inGame = true;
                            currentGameState = GameState.Playing;  // Transition to the gameplay state
                            base.Initialize();
                        }
                        else if (shipSelectionMenu.back)
                        {
                            currentGameState = GameState.MainMenu; //Transistions back to main menu
                            base.Initialize();
                        }
                        break;

                    case GameState.Playing:
                        // Add your game logic here
                        // When the game is over, reset to main menu

                        break;

                    case GameState.Settings:
                        // Add settings logic here (not implemented)
                        break;

                    case GameState.Exit:

                        Exit();

                        break;
                }

                base.Update(gameTime);
                return;
            }
            else
            {
                if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                    Exit();

                _player1grid!.Update();
                _player2grid!.Update();

                Tuple<int, int> currentPlayer1TileLocation = _player1grid.GridArray.CoordinatesOf(_player1grid.CurrentTile);
                Tuple<int, int> currentPlayer2TileLocation = _player2grid.GridArray.CoordinatesOf(_player2grid.CurrentTile);

                if (_shipManager!.IsPlayer1Placing && _player1grid.CurrentTile is not null)
                    _cursor.UpdateWhilePlacing(_player1grid.CurrentTile, currentPlayer1TileLocation, _shipManager.CurrentShipSize);
                else if (_player1grid.CurrentTile is not null)
                    _cursor.UpdateWhilePlaying(_player1grid.CurrentTile, currentPlayer1TileLocation.Item1);

                if (_shipManager!.IsPlayer2Placing && _player2grid.CurrentTile is not null)
                    _cursor.UpdateWhilePlacing(_player2grid.CurrentTile, currentPlayer2TileLocation, _shipManager.CurrentShipSize);
                else if (_player2grid.CurrentTile is not null)
                    _cursor.UpdateWhilePlaying(_player2grid.CurrentTile, currentPlayer2TileLocation.Item1);

                if (_shipManager!.IsPlayer1Placing && _player1grid.CurrentTile is not null)
                    _shipManager.UpdateWhilePlacing(_player1grid.CurrentTile, _cursor.Orientation, 1);
                if (_shipManager!.IsPlayer2Placing && _player2grid.CurrentTile is not null)
                    _shipManager.UpdateWhilePlacing(_player2grid.CurrentTile, _cursor.Orientation, 2);

                // Check if all ships have been placed
                if (!_shipManager.IsPlacingShips)
                {
                    _shipManager.HideP2Ships = true;
                    HandleShooting();
                }

                base.Update(gameTime);
            }
        }

        /// <summary>
        /// Draws objects to the screen. Called constantly in a loop.
        /// </summary>
        /// <param name="gameTime">The current game time.</param>
        protected override void Draw(GameTime gameTime)
        {
            if (!inGame)
            {
                GraphicsDevice.Clear(Color.CornflowerBlue);

                _spriteBatch.Begin();

                if (currentGameState == GameState.MainMenu)
                {
                    menu.Draw(_spriteBatch);
                }
                else if (currentGameState == GameState.ShipSelection)
                {
                    shipSelectionMenu.Draw(_spriteBatch);
                }
                else if (currentGameState == GameState.Playing)
                {
                    // Add drawing code for the game here
                }

                _spriteBatch.End();

                base.Draw(gameTime);
                return;
            }
            GraphicsDevice.Clear(Color.CornflowerBlue);

            _spriteBatch!.Begin(samplerState: SamplerState.PointClamp);
            _player1grid!.Draw(_spriteBatch);
            _player2grid!.Draw(_spriteBatch);
            _shipManager!.Draw(_spriteBatch);
            _cursor.Draw(_spriteBatch);
            _spriteBatch!.End();

            base.Draw(gameTime);
        }
        /// <summary>
        /// Handles shooting logic for the game.
        /// </summary>
        private void HandleShooting()
        {
            if (!inGame)
            {
                return;
            }
            MouseState mouseState = Mouse.GetState();
            if (mouseState.LeftButton == ButtonState.Pressed)
            {
                Point mousePoint = new Point(mouseState.X, mouseState.Y);
                bool? hit = _player2grid!.Shoot(mousePoint);
            }
        }
    }
}