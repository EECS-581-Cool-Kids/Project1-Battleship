﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

public class Postgame
{
    private SpriteFont _font;         // Font used for the text
    private string _winnerMessage;    // Message to display on the screen
    private bool _isActive;           // Determines if the postgame screen is active

    // Constructor that initializes the font and winner message
    public Postgame(SpriteFont font)
    {
        _font = font;
        _winnerMessage = "";
        _isActive = false;
    }

    // Method to set the winner message based on the player who won
    public void SetWinner(bool player1Wins)
    {
        _isActive = true; // Activate the postgame screen
        if (player1Wins)
        {
            _winnerMessage = "Player 1 Wins!";
        }
        else
        {
            _winnerMessage = "Player 2 Wins!";
        }
    }

    // Method to deactivate the postgame screen
    public void Deactivate()
    {
        _isActive = false;
    }

    // Update logic (optional)
    public void Update(GameTime gameTime)
    {
        // Optional logic if needed, e.g., to wait for input or fade the screen
    }

    // Method to draw the winner message on the screen
    public void Draw(SpriteBatch spriteBatch, GraphicsDeviceManager graphics)
    {
        if (_isActive)
        {
            spriteBatch.Begin();

            // Center the message on the screen
            Vector2 position = new Vector2(graphics.PreferredBackBufferWidth / 2, graphics.PreferredBackBufferHeight / 2);
            Vector2 textSize = _font.MeasureString(_winnerMessage);
            Vector2 origin = textSize / 2;

            // Draw the message
            spriteBatch.DrawString(_font, _winnerMessage, position, Color.White, 0, origin, 1.0f, SpriteEffects.None, 0);

            spriteBatch.End();
        }
    }
}
